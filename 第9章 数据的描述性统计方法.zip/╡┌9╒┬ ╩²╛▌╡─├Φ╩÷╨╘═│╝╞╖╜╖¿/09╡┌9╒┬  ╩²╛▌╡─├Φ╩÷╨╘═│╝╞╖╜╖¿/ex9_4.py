#程序文件ex9_4.py
from scipy.stats import expon
print(expon.stats(scale=3, moments='mvsk'))


