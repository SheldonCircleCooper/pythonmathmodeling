# -*- coding: utf-8 -*-
"""
Created on Fri Jul  1 22:13:58 2022

@author: 姚小妞
"""

from scipy.stats import norm
import pylab as plt
x = plt.linspace(-3, 3, 100)
plt.plot(x, norm.pdf(x, 0,1))
plt.xlabel('x')
plt.ylabel('f(x)')
plt.legend()
plt.show()
