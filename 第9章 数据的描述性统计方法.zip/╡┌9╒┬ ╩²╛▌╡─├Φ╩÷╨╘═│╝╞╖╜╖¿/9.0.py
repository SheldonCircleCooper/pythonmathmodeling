# -*- coding: utf-8 -*-
"""
Created on Fri Jul  1 15:29:33 2022

@author: 姚小妞
"""

from scipy import stats
[k for k, v in stats.__dict__.items() if isinstance(v, stats.rv_continuous)]  #显示90多个连续型分布的名称
y=stats.norm.pdf(0,0,1)   #标准正态分布下，求概率密度函数值f(0)
F=stats.norm.cdf(0,0,1)   #标准正态分布下，求分布函数值F(0)
n=stats.norm.rvs(0,1,size=100)   #生成100个整体服从标准正态分布的随机数，生成样本