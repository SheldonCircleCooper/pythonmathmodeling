# -*- coding: utf-8 -*-
"""
Created on Fri Jul  1 22:24:16 2022

@author: 姚小妞
"""

from scipy.stats import norm
from scipy.optimize import fsolve

c1 = norm.ppf(0.25, 3, 2)  #求0.25分位数
fc = lambda c: 1-norm.cdf(c, 3, 2)-3*norm.cdf(c, 3, 2)  #定义方程对应的匿名函数
c2 = fsolve(fc, 1)  #求初始值为1的方程零点，求解方程1-P{X<C}-3P{X<C}=0的解
#该方程只有一个解，，初始值的设置对方程的解没有影响
print('c1=', c1); print('c2=', c2)
