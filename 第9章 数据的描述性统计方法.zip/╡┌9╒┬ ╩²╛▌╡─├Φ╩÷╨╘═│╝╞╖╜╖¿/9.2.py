# -*- coding: utf-8 -*-
"""
Created on Fri Jul  1 21:51:07 2022

@author: 姚小妞
"""

from scipy.stats import binom
import pylab as plt   #pylab 是 matplotlib 面向对象绘图库的一个接口,常用来画线图

n = 6; p = 0.3
x = plt.arange(7)
y = binom.pmf(x, n, p)
plt.subplot(121)
plt.plot(x, y, 'ro')
plt.vlines(x, 0, y, 'k', lw=2, alpha=0.5)  #vlines(x, ymin, ymax)画竖线图
#lw设置线宽度，alpha设置图的透明度
plt.subplot(122)
plt.stem(x, y, use_line_collection=True)#创建茎图,在每个x位置绘制从基线到y坐标的垂直线，并在此处放置标记
#use_line_collection如果为True，则将干线存储并绘制为LineCollection（线集），而不是单独的一些线段
plt.savefig("figure9_2.png", dpi=500)
plt.show()
